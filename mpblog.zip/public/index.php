<?php

require __DIR__ . '/../app/bootstrap.php';

$app->run();